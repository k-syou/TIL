from billiards_assets import *
from straight_shot import *
from one_cution import *
import socket

order = 0
balls = [[0, 0] for i in range(NUMBER_OF_BALLS)]

sock = socket.socket()
print("Trying to Connect: %s:%d" % (HOST, PORT))
sock.connect((HOST, PORT))
print("Connected: %s:%d" % (HOST, PORT))

send_data = "%d/%s" % (CODE_SEND, NICKNAME)
sock.send(send_data.encode("utf-8"))
print("Ready to play!\n--------------------")

while True:

    # Receive Data
    recv_data = (sock.recv(1024)).decode()
    print("Data Received: %s" % recv_data)

    # Read Game Data
    split_data = recv_data.split("/")
    idx = 0
    try:
        for i in range(NUMBER_OF_BALLS):
            for j in range(2):
                balls[i][j] = float(split_data[idx])
                idx += 1
    except:
        send_data = "%d/%s" % (CODE_REQUEST, NICKNAME)
        print("Received Data has been currupted, Resend Requested.")
        continue

    # Check Signal for Player Order or Close Connection
    if balls[0][0] == SIGNAL_ORDER:
        order = int(balls[0][1])
        print(
            "\n* You will be the %s player. *\n" % ("first" if order == 1 else "second")
        )
        continue
    elif balls[0][0] == SIGNAL_CLOSE:
        break

    # Show Balls' Position
    print("====== Arrays ======")
    for i in range(NUMBER_OF_BALLS):
        print("Ball %d: %f, %f" % (i, balls[i][0], balls[i][1]))
    print("====================")

    angle = 0.0
    power = 0.0

    # 테스트 코드
    # data_str = "64/64/190/64/-1/-1/198/78/-1/-1/198.5/63.5/"
    # data_str = "64/64/250/122/-1/-1/-1/-1/-1/-1/-1/-1/"
    data_str = "128/105/250/122/120/8/6/6/173/45/127/64/"
    # data_str = "64/64/-1/-1/120/8/-1/-1/173/45/127/64/"
    # data_str = "64/64/-1/-1/-1/-1/-1/-1/-1/-1/250/120/"
    player = 1 if order == 1 else 0

    whiteBall_x = balls[0][0]
    whiteBall_y = balls[0][1]
    cue_ball = Ball(0, whiteBall_x, whiteBall_y)

    # targetBall_x, targetBall_y: 목적구의 X, Y좌표를 나타내기 위해 사용한 변수
    target_balls = []
    for i, (ball_x, ball_y) in enumerate(balls[1:]):
        # 타겟 공들을 리스트에 담음
        if ball_x == -1:
            continue
        num = i + 1
        if num == 5:
            num = 8
        target_ball = Ball(num, ball_x, ball_y)
        target_balls.append(target_ball)

    table = PoolTable()
    # table_map = [
    #     [" "] * (int(table.W) // 10 + 1) for _ in range(int(table.H) // 10 + 1)
    # ]
    # print(f"cue_ball : {cue_ball.x}, {cue_ball.y}")

    # table_map[round(cue_ball.y / 10)][round(cue_ball.x / 10)] = "W"
    # for target_ball in target_balls:
    #     table_map[round(target_ball.y / 10)][
    #         round(target_ball.x / 10)
    #     ] = target_ball.num
    # print("H------------------------H------------------------H")
    # for row in table_map[1:][::-1]:
    #     print("|", end="")
    #     print(*row[1:], end="")
    #     print("|")
    # print("H------------------------H------------------------H")

    # holes = table.get_holes()
    other_balls = deque(target_balls)

    import heapq

    success = []
    max_diff = 90
    max_dist = pythagoras(table.W, table.H)
    for _ in range(len(target_balls)):
        target_ball = other_balls.popleft()
        print(f"\n\nball number : {target_ball.num}")
        for hole in HOLES:
            if target_ball.num == 8:
                other_balls_nums = [other_ball.num for other_ball in other_balls]
                que8 = True
                for num in other_balls_nums:
                    if num % 2 == player:
                        que8 = False
                        break
                if not que8:
                    continue
            elif target_ball.num % 2 != player:
                continue
            result = straight_shot(cue_ball, target_ball, hole, other_balls)
            # result = False
            result2 = one_cution(cue_ball, target_ball, table, hole, other_balls)
            if result:
                cue_angle, ball_angle, tot_dist, goals = result
                if abs(cue_angle - ball_angle) >= 90:
                    continue
                heapq.heappush(
                    success,
                    (
                        abs(cue_angle - ball_angle) / max_diff + tot_dist / max_dist,
                        abs(cue_angle - ball_angle),
                        tot_dist,
                        cue_angle,
                        ball_angle,
                        goals,
                        hole,
                        target_ball.num,
                        False,
                    ),
                )
                print(
                    f"straight   : {target_ball.num}번 공을 {cue_angle} 각도로 치면 들어갑니다! {goals}"
                )
            for r2 in result2:
                cue_angle, ball_angle, tot_dist, goals = r2
                if abs(cue_angle - ball_angle) >= 90:
                    continue
                heapq.heappush(
                    success,
                    (
                        (abs(cue_angle - ball_angle) / max_diff + tot_dist / max_dist)
                        + 0.5,
                        abs(cue_angle - ball_angle),
                        tot_dist,
                        cue_angle,
                        ball_angle,
                        goals,
                        hole,
                        target_ball.num,
                        True,
                    ),
                )
                print(
                    f"one cution : {target_ball.num}번 공을 {cue_angle} 각도로 치면 들어갑니다! {goals}"
                )

        other_balls.append(target_ball)

    idx = 0
    post_data = ""
    if not success:
        for target_ball in target_balls:
            if target_ball.num % 2 == player:
                cx, cy = cue_ball.get_loc()
                tx, ty = target_ball.get_loc()
                quadrant = get_quadrant(cx, cy, tx, ty)
                if quadrant == 2:
                    ty += (cy - ty) * 2
                elif quadrant == 3:
                    tx += (cx - tx) * 2
                    ty += (cy - ty) * 2
                elif quadrant == 4:
                    tx += (cx - tx) * 2

                angle = get_atan_angle(tx - cx, ty - cy)
                if quadrant % 2:  # 1, 3 사분면
                    angle += (quadrant - 1) * 90
                else:  # 2, 4 사분면
                    angle = quadrant * 90 - angle
                break
        post_data = f"{angle}/70"

    while success:
        _, diff, dist, angle, ball_angle, goals, hole, num, is_one_cution = (
            heapq.heappop(success)
        )
        # 세게 치는게 좋다고 하니..
        power = (diff / max_diff) * 50 + (dist / max_dist) * 50
        if power >= 100:
            power = 100
        if idx == 0:
            post_data = f"{angle}/{power}/"
            # post_data = f"{angle}/50/"
        idx += 1
        print(
            "one" if is_one_cution else "str",
            num,
            round(angle, 3),
            round(ball_angle, 3),
            round(power),
            hole,
        )

    print(f"\n최종적으로 {post_data} 값을 넘겨준다.")

    merged_data = post_data
    sock.send(merged_data.encode("utf-8"))
    print("Data Sent: %s" % merged_data)

sock.close()
print("Connection Closed.\n--------------------")
